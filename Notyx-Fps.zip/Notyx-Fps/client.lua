-- ==================== NOTYX-FPS CLIENT ====================

local menuOpen   = false
local fps        = 0
local frameCount = 0
local lastTime   = GetGameTimer()
local activeTimecycle = 'none'

-- Timecycles verificados que funcionan en FiveM
-- Combinamos SetTimecycleModifier + SetExtraTimecycleModifier para más efecto
local timecycles = {
    none       = { tc = nil,                         extra = nil },
    low        = { tc = 'exile1_plane',              extra = nil },
    rapid      = { tc = 'yell_tunnel_nodirect',      extra = nil },
    ultraboost = { tc = 'yell_tunnel_nodirect',      extra = 'MP_corona_creation' },  -- NUEVO: rapid + extra agresivo
    lowTexture = { tc = 'v_janitor',                 extra = nil },
    noGpu      = { tc = 'HicksbarNEW',               extra = nil },
    nosky      = { tc = 'no_sky',                    extra = nil },
    betterGfx  = { tc = 'v_torture',                 extra = 'reflection_correct_ambient' },
    vignette   = { tc = 'rply_vignette',             extra = nil },
    blackwhite = { tc = 'NG_filmnoir_BW01',          extra = nil },
    heat       = { tc = 'xs_heat',                   extra = nil },
    night      = { tc = 'hud_def_vig_night_mp',      extra = nil },
    fog        = { tc = 'NG_filmdirty_CC01',         extra = nil },
}

-- ==================== FPS COUNTER ====================
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        frameCount = frameCount + 1
        local now     = GetGameTimer()
        local elapsed = now - lastTime
        if elapsed >= 500 then
            fps        = math.floor((frameCount / elapsed) * 1000)
            frameCount = 0
            lastTime   = now
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        if menuOpen then
            SendNUIMessage({ action = 'updateFps', fps = fps })
        end
    end
end)

-- ==================== APLICAR TIMECYCLE CADA FRAME ====================
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local preset = timecycles[activeTimecycle]
        if preset and preset.tc then
            SetTimecycleModifier(preset.tc)
            SetTimecycleModifierStrength(1.0)
            if preset.extra then
                SetExtraTimecycleModifier(preset.extra)
            end
        end
    end
end)

-- ==================== LIMPIAR EFECTOS ====================
local function ClearEffects()
    local ped = PlayerPedId()
    ClearAllBrokenGlass()
    ClearAllHelpMessages()
    ClearBrief()
    ClearGpsFlags()
    ClearPrints()
    ClearSmallPrints()
    ClearFocus()
    ClearHdArea()
    ClearPedBloodDamage(ped)
    ClearPedWetness(ped)
    ClearPedEnvDirt(ped)
    ResetPedVisibleDamage(ped)
    DisableScreenblurFade()
    SetRainLevel(0.0)
    SetWindSpeed(0.0)
end

-- ==================== RESET ====================
local function ResetAll()
    activeTimecycle = 'none'
    ClearTimecycleModifier()
    ClearExtraTimecycleModifier()
    -- Restaurar lluvia al clima del servidor
    SetRainLevel(-1.0)
    print('^3[Notyx-Fps]^7 Timecycle ^2RESETEADO^7')
end

-- ==================== NUI CALLBACKS ====================
RegisterNUICallback('applyTimecycle', function(data, cb)
    local prev = activeTimecycle
    activeTimecycle = data.timecycle or 'none'

    -- Limpiar el timecycle anterior antes de aplicar el nuevo
    ClearTimecycleModifier()
    ClearExtraTimecycleModifier()
    Citizen.Wait(50)

    -- Limpiar efectos visuales
    ClearEffects()

    print('^3[Notyx-Fps]^7 Preset: ^2' .. activeTimecycle .. '^7')
    cb('ok')
end)

RegisterNUICallback('resetSettings', function(_, cb)
    ResetAll()
    cb('ok')
end)

RegisterNUICallback('closeMenu', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    cb('ok')
end)

-- ==================== ABRIR MENÚ ====================
local function OpenMenu()
    if menuOpen then return end
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', timecycle = activeTimecycle })
end

-- ==================== COMANDOS ====================
RegisterCommand('fps', function(source, args)
    local arg = args[1] and args[1]:lower()
    if arg == 'reset' then ResetAll()
    else OpenMenu() end
end, false)

RegisterCommand('fps_reset', function() ResetAll() end, false)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if menuOpen and IsControlJustReleased(0, 200) then
            menuOpen = false
            SetNuiFocus(false, false)
            SendNUIMessage({ action = 'close' })
        end
    end
end)

exports('openMenu', OpenMenu)
exports('reset',    ResetAll)
exports('getFps',   function() return fps end)