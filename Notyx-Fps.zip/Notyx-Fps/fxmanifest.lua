fx_version 'cerulean'
game 'gta5'
lua54 'yes'
description 'Notyx FPS'
version '2.0.0'

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}