'use strict';

const overlay  = document.getElementById('overlay');
const btnClose = document.getElementById('btn-close');
const btnReset = document.getElementById('btn-reset');
const fpsEl    = document.getElementById('fps-val');

function getResourceName() {
    return typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'Notyx-Fps';
}
function post(event, data) {
    fetch(`https://${getResourceName()}/${event}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(data || {})
    });
}

let activeTimecycle = 'none';

document.querySelectorAll('.preset-card').forEach(card => {
    card.addEventListener('click', () => {
        activeTimecycle = card.dataset.tc;
        document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        post('applyTimecycle', { timecycle: activeTimecycle });
    });
});

function updateFps(fps) {
    fpsEl.textContent = fps;
    fpsEl.className = 'fps-value' + (fps >= 60 ? '' : fps >= 40 ? ' mid' : ' low');
}

btnReset.addEventListener('click', () => {
    activeTimecycle = 'none';
    document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('active'));
    const normal = document.querySelector('.preset-card[data-tc="none"]');
    if (normal) normal.classList.add('active');
    post('resetSettings');
});

btnClose.addEventListener('click',   () => post('closeMenu'));
overlay.addEventListener('mousedown', e => { if (e.target === overlay) post('closeMenu'); });
document.addEventListener('keydown',  e => { if (e.key === 'Escape') post('closeMenu'); });

window.addEventListener('message', e => {
    const d = e.data;
    if (d.action === 'open') {
        overlay.classList.remove('hidden');
        overlay.classList.add('visible');
        if (d.timecycle) {
            activeTimecycle = d.timecycle;
            document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('active'));
            const active = document.querySelector(`.preset-card[data-tc="${d.timecycle}"]`);
            if (active) active.classList.add('active');
        }
    }
    if (d.action === 'close')     { overlay.classList.remove('visible'); overlay.classList.add('hidden'); }
    if (d.action === 'updateFps') updateFps(d.fps || 0);
});